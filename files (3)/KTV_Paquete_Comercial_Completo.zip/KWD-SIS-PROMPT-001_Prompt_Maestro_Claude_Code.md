# PROMPT MAESTRO PARA CLAUDE CODE — Sistema Comercial KTV Working Drone Colombia

> Pega este archivo completo como primer mensaje en Claude Code. Está diseñado para desarrollarse POR ETAPAS: Code debe proponer arquitectura y esperar tu visto bueno antes de programar cada módulo. No aprobar todo de una vez.

---

## CONTEXTO DEL NEGOCIO

KTV Working Drone Colombia S.A.S. (NIT 901.830.814-8) es la franquicia colombiana de KTV Working Drone AS (Noruega, 68 países). Presta servicios de lavado, inspección e impermeabilización de fachadas con drones (UAS). Es el único operador con Certificado de Explotador UAS vigente de la Aeronáutica Civil en su categoría.

- Marca: azul corporativo **#2E75B6**, azul oscuro **#1F4E78**, blanco. Logo: ktvwd23.png (se entregará).
- Idioma: español de Colombia. Moneda: COP. Todos los precios se muestran **+ IVA**.
- CRM en uso: **Pipedrive** (ya configurado, se entregará API token).
- Plataforma de facturación de la franquicia: BlueTag (NO integrar ahora).
- Sitio actual: landing de prospección en colombia.ktvworkingdrone.com.co (solo referencia visual).

## OBJETIVO GLOBAL

Construir el **motor comercial digital** de KTV, en módulos independientes pero integrados. NO automatizar procesos operativos (flota, bitácoras, compliance): esos cambiarán tras la inspección de Aerocivil y se harán después. Alcance de ESTE desarrollo:

1. **Cotizador** con motor de precios y control de autorización.
2. **Presentador de propuestas web** (brochure público sin precios + propuesta/cotización con precios controlada).
3. **Integración con Pipedrive** (leads, deals, tracking de apertura, registro de llamadas).
4. **Agente de alertas comerciales** que analiza Pipedrive y recomienda próximos pasos.

Stack sugerido: **React + backend Node/Python con base de datos (PostgreSQL)**. Autenticación con roles (Gerencia / Director Comercial / Comercial). Panel de administración donde Gerencia edita TODOS los parámetros sin tocar código. Desplegable en subdominio propio.

---

## REGLAS DE NEGOCIO CRÍTICAS (el motor DEBE respetarlas)

### Lógica de precios: cotizar por m², costear por días
- Al cliente se le cotiza **por metro cuadrado** (o por sitio, en inspección). El costo interno se calcula **por días**. Puente: `días = ⌈m² ÷ productividad⌉` redondeado a medio día, + medio día de montaje si el sitio es complejo.
- **Nunca** mostrar días al cliente en la cotización; es cálculo interno.

### Parámetros editables por Gerencia (pantalla de configuración, NO hardcodear)
| Parámetro | Valor inicial |
|---|---|
| Tarifa lista lavado | 6000 COP/m² |
| TRM | 3727.2 COP/USD (editable) |
| EUR/COP | 4400 (editable) |
| Banda franquiciante | USD 1.5 – 2.0 /m² (límite de referencia) |
| Fee Noruega sobre facturación | 3.5% |
| Comisión venta en frío / referido / renovación | 5% / 3% / 1% |
| % Administración / % Imprevistos | 10% / 5% |
| Productividad vidrio / mixta / difícil | 1350 / 900 / 600 m²/día |
| Cuadrilla por día (2 pilotos + conductor) | 524049 COP/día |
| Consumibles por día (incluye combustible, NUNCA cobrar gasolina aparte) | 260034 COP/día |
| Depreciación equipos por día | 683118 COP/día |
| Costo operativo por día resultante | ~1687281 COP/día (= (cuadrilla+consumibles+depreciación) × 1.15) |
| Fee inspección Noruega por techo | 798 / 1198 / 1598 EUR (0-10k / 10-25k / 25-40k m²) |
| Margen mínimo autorizado sin aprobación | 25% |
| BlueTag (costo fijo) | 350 USD/mes |

### Recargos (selector Bajo/Medio/Alto, NO %libre)
- Tipo de edificio: Bajo 0% / Medio 5% / Alto 10%
- Dificultad: Bajo 0% / Medio 5% / Alto 10%

---

## MÓDULO 1 — COTIZADOR

Cotiza estos servicios (**NO incluir robot J1 ni fumigación** — el robot es ventaja competitiva reservada; la fumigación no está desarrollada):

**a) Lavado** (por m²): entradas m², tipo superficie, tipo edificio, dificultad, ciudad (Bogotá/fuera), tarifa editable (default 6000). Fuera de Bogotá suma movilización (tráiler, peajes, hotel×personas×noches, pasajes×personas, viáticos×personas×días; la gasolina de operación YA está en consumibles). Salidas: días, costo, precio sugerido, margen $ y %, precio piso (margen 0), precio mínimo autorizado (margen 25%), tarifa en USD/m² para control de banda.

**b) Impermeabilización** (por m², línea separada del lavado): son DOS pasadas (lavado + aplicación). Costo ≈ 2× operación + material. Campo de costo de material por m² (variable, se cotiza por edificio) facturado con +15% administración. Nunca presentar como "el doble de metros".

**c) Inspección** (por SITIO según área de TECHO, no por m² de fachada): cuadrilla 2 pilotos + conductor, sin consumibles de lavado. Dos niveles:
   - **Diagnóstico Visual KTV** (informe propio, sin fee Noruega): precio 3–5.5M, el único que se puede regalar/50% como gancho.
   - **Inspección Certificada** (compra informe a Noruega): precio = 2× fee Noruega + operación (~8–15M), NUNCA se descuenta. Se vende como "soporte técnico bajo estándar internacional" (sin prometer validez ante aseguradoras).

**d) Terceros y materiales** (cualquier servicio): campo de subcontratos; NUNCA se absorben al costo, se facturan al cliente con +15% administración.

**e) Paquetes KTV Care** (recurrentes, por m² con descuento por compromiso):
   - Inspect: solo inspección anual (DV o Certificado a elección).
   - Essential: inspección (DV incluido) + 1 lavada/año a 5700/m².
   - Complete: inspección (DV incluido; Certificado en versión institucional) + 2 lavadas/año a 5400/m².
   - Duración 1 o 3 años (3 años: sin descuento adicional, congela año 1 + IPC años 2-3).
   - Pago contado o diferido 12 meses (**diferir NO es descuento**; descuento solo por anticipado).

**Control de precios (CRÍTICO):** el sistema no permite emitir cotización final bajo el mínimo autorizado (margen 25%) ni bajo USD 1.5/m² sin marcar "requiere aprobación de Gerencia". Toda cotización lleva **"precio válido por 30 días"**. Una cotización enviada es una foto congelada: cambiar parámetros solo afecta cotizaciones nuevas.

---

## MÓDULO 2 — PRESENTADOR DE PROPUESTAS

Dos tipos de documento generables (web + PDF descargable):

**a) Brochure público (SIN precios):** servicios (lavado, impermeabilización, ventanas, paneles, inspección — sin robot ni fumigación), método, respaldo (68 países, operador certificado, verificable en listado público de Aerocivil), casos/videos, diferenciadores vs tradicional (cero alturas, 3-5× más rápido, agua pura sin contacto, documentación). Se comparte por link abierto. Para prospección en frío.

**b) Propuesta confidencial CON precios:** los paquetes Care y/o la cotización específica. Solo a cuentas clave. **Marca de agua con el nombre del destinatario + identificador único de trazabilidad** para detectar filtraciones. Acceso por link único con vigencia (30 días).

**Formato de cotización = menú de 3 opciones** (A Lavado puntual / B Lavado + Diagnóstico / C KTV Care), mostrando SIEMPRE el valor total del proyecto primero; el desglose por m² solo si se solicita. Para proyectos con varios servicios (ej. centro comercial 12.000 m²): líneas separadas — Inspección (por techo) + Lavado (por m²) + Impermeabilización (por m² tarifa superior + Sika).

**Tracking:** notificar a Gerencia/Comercial cuando el cliente ABRE la propuesta (fecha/hora); registrar aperturas.

---

## MÓDULO 3 — INTEGRACIÓN PIPEDRIVE

- Al aprobarse y enviarse una cotización/propuesta, **crear o actualizar el deal** en Pipedrive vía API (persona/organización + deal con etapa y valor). Adjuntar la cotización.
- Registrar el evento de **apertura de propuesta** como actividad/nota en el deal.
- **Formulario de la landing y del presentador → crear lead automáticamente** en Pipedrive (para no perder prospección en frío).
- **Llamadas telefónicas:** Pipedrive ofrece registro de llamadas nativo (Pipedrive Phone) y vía marketplace (Aircall, JustCall, Kavkom). Documentar la opción recomendada y, si se elige integración por API, registrar cada llamada (duración, resultado, grabación si aplica) en el deal correspondiente. Confirmar con Gerencia qué proveedor de telefonía usa antes de desarrollar esta parte.
- API token de Pipedrive configurable en ajustes (NO hardcodear).

---

## MÓDULO 4 — AGENTE DE ALERTAS COMERCIALES

Un agente que consulta Pipedrive periódicamente y genera alertas/recomendaciones accionables para el equipo. Reglas iniciales (editables por Gerencia):
- Lead sin primer contacto > 24h → alerta al comercial (KTV promete respuesta en 24h).
- Deal sin actividad registrada > 5 días → alerta de seguimiento.
- Propuesta abierta por el cliente pero sin seguimiento en 48h → alerta "cliente interesado, contactar ya".
- Propuesta enviada y no abierta en 5 días → alerta "reintentar por otro canal".
- Cotización próxima a vencer (vigencia 30 días, avisar al día 25) → alerta de renovación de precio.
- Contrato Care próximo a renovación (60 días antes) → alerta de retención.
- Resumen semanal para Gerencia: embudo, tasa de conversión, negocios estancados, proyección vs meta del Plan de Comisiones (KWD-COM-PCM-001: metas $15M meses 1-2 / $28M meses 3-4 / $40M mes 5+).

El agente debe **explicar cada alerta** ("por qué te aviso esto y qué hacer"), no solo listarla. Puede usar la API de Claude para redactar la recomendación y el resumen ejecutivo en lenguaje natural.

---

## ROLES Y AUTORIZACIÓN

- **Comercial:** crea cotizaciones (cualquier precio, incluso bajo mínimo), pero NO puede enviarlas. Quedan "pendientes de aprobación".
- **Director Comercial (rol futuro):** gestiona equipo, ve panel agregado; nivel de aprobación configurable.
- **Gerencia:** aprueba/rechaza CADA cotización antes del envío. Solo tras aprobación se genera el link enviable. Edita parámetros y reglas.
- **Auditoría:** registro de quién cotizó, qué precio, quién aprobó, cuándo se envió, cuándo se abrió.

---

## ENTREGABLES Y FORMA DE TRABAJO

Entregables: (1) cotizador con parámetros editables; (2) generador de brochure público y propuesta confidencial con marca de agua/trazabilidad; (3) flujo de aprobación Comercial→Gerencia→envío; (4) tracking de apertura; (5) integración Pipedrive (leads, deals, apertura, llamadas); (6) agente de alertas con resumen semanal; (7) panel de auditoría.

Dejar arquitectura preparada para sumar módulos operativos después (post-Aerocivil) SIN construirlos ahora.

**Forma de trabajo obligatoria:** empieza proponiendo la arquitectura, el modelo de datos y el orden de construcción de los módulos. Espera mi aprobación antes de escribir código. Construye un módulo a la vez, muéstramelo funcionando, y solo entonces pasa al siguiente. Prioriza que Gerencia pueda operar todo sin tocar código.

---

## ANEXO TÉCNICO — ARQUITECTURA DE LA ESTRUCTURA DE PRECIOS (LEER ANTES DE PROGRAMAR EL MÓDULO 1)

Esta sección es de obligatorio cumplimiento para el backend. El objetivo es que la lógica de precios sea **robusta, sin números quemados, auditable y modificable en el tiempo sin romper cotizaciones ya emitidas.**

### Principio 1 — Ningún valor quemado en el código
Todos los parámetros (tarifas, fees, comisiones, productividades, costos diarios, recargos, umbrales de rango de techo, márgenes mínimos) viven en una tabla de base de datos `pricing_parameters`, editable desde el panel de Gerencia. El motor de cálculo LEE de esa tabla; nunca tiene constantes hardcodeadas. Cambiar un precio = cambiar un registro, sin tocar código ni redesplegar.

### Principio 2 — Versionado de parámetros (crítico para no romper el pasado)
La tabla `pricing_parameters` es **versionada e inmutable hacia atrás**: cada cambio crea una nueva versión con `valid_from` (fecha/hora), y las versiones anteriores se conservan. Cada cotización emitida guarda el `pricing_version_id` con el que se calculó. Consecuencia obligatoria:
- Una cotización **ya emitida** SIEMPRE se puede recalcular/mostrar con los parámetros vigentes al momento de su emisión (foto congelada real, no simulada).
- Cambiar un parámetro hoy afecta solo cotizaciones NUEVAS, jamás recalcula ni altera las emitidas.
- Debe existir un historial consultable: "qué parámetros regían el 15 de marzo".

### Principio 3 — Motor de cálculo como servicio puro y testeable
El cálculo de precios es una función pura `calcularCotizacion(inputs, pricingVersion) → resultado`, sin efectos secundarios, con pruebas unitarias que cubran: edificio pequeño/mediano/grande, Bogotá/fuera, cada tipo de superficie, cada nivel de recargo, con/sin comisión, cada rango de techo, y los casos límite (0 m², margen negativo, tarifa bajo el mínimo). Si un cambio de parámetros rompe un test, el sistema avisa antes de guardar.

### Modelo de datos mínimo de precios
```
pricing_parameters (versionado)
  - id, version_id, valid_from, created_by
  - tarifa_lista_lavado, trm, eur_cop
  - banda_franq_min_usd, banda_franq_max_usd
  - fee_noruega_pct (0.035)
  - comision_frio_pct, comision_referido_pct, comision_renovacion_pct
  - pct_administracion, pct_imprevistos
  - prod_vidrio, prod_mixta, prod_dificil   (m²/día)
  - cuadrilla_dia, consumibles_dia, depreciacion_equipos_dia
  - margen_minimo_autorizado_pct (0.25)
  - descuento_care_essential_pct (0.05), descuento_care_complete_pct (0.10)

roof_inspection_tiers (versionado, rangos EDITABLES)
  - id, version_id, techo_min_m2, techo_max_m2, fee_noruega_eur
  # 0-10000 → 798 ; 10000-25000 → 1198 ; 25000-40000 → 1598
  # el motor busca el rango donde cae el techo y toma su fee; si supera el máx → "precio a solicitud"

movilizacion_params (versionado)
  - trailer, peaje, hotel_persona_noche, pasaje_persona, viaticos_persona_dia

quotes (cotizaciones emitidas — inmutables)
  - id, cliente_id, pricing_version_id (FK), estado (borrador/pendiente/aprobada/enviada/vencida)
  - creada_por, aprobada_por, fecha_emision, fecha_vencimiento (emision + 30 días)
  - snapshot_json (copia completa de inputs y resultados al momento de emitir)
```

### Reglas de cálculo que el motor DEBE implementar (explícitas)
1. **Días** = techo(m²_fachada ÷ productividad_segun_superficie) redondeado a 0.5, + 0.5 si sitio complejo.
2. **Costo operativo día** = (cuadrilla_dia + consumibles_dia + depreciacion_equipos_dia) × (1 + pct_administracion + pct_imprevistos).
3. **Lavado**: costo = días × costo_op_dia × (1 + recargo_edificio + recargo_dificultad) + movilización(si fuera de Bogotá). Precio = m² × tarifa_del_proyecto (editable, default tarifa_lista). Fee Noruega = precio × 0.035. Comisión = precio × pct_segun_origen.
4. **Impermeabilización**: DOS pasadas (días_lavado + días_aplicacion) × costo_op_dia + material×m²×(1+0.15). Línea separada del lavado.
5. **Diagnóstico Visual** (informe propio): costo = fracción_dia × costo_op_dia (SIN fee Noruega por informe). Precio de venta editable. VA INCLUIDO en el precio de los paquetes Care (su costo se suma al total del paquete; nunca es $0 ni "gratis" contablemente).
6. **Inspección Certificada** (informe Noruega): busca el tier por área de TECHO, toma fee_noruega_eur, convierte a COP (×eur_cop). Precio = 2×fee_cop + costo_operación. NUNCA descontable. Se cobra APARTE de los paquetes (upsell), salvo Care Complete institucional donde el fee va cargado en el precio del contrato.
7. **Paquetes Care** (por edificio, con m² reales):
   - Inspect = precio del informe elegido (DV o Certificado).
   - Essential = (m² × tarifa_lista × (1−0.05)) [lavada] + costo/precio del Diagnóstico Visual [incluido].
   - Complete = (2 × m² × tarifa_lista × (1−0.10)) [2 lavadas] + Diagnóstico Visual [incluido] (+ Certificado cargado solo en versión institucional).
   - Valor mensual = valor_anual ÷ 12 (diferido; NO cambia el total).
8. **Validaciones de guarda**: si margen resultante < margen_minimo_autorizado → bloquear emisión y exigir aprobación de Gerencia. Si tarifa < banda_franq_min_usd (convertida) → exigir doble aprobación. Nunca permitir emisión que viole estas reglas sin el flag de aprobación correspondiente registrado.

### Salidas del motor (para el frontend y la propuesta)
Para cada edificio cotizado, el motor devuelve los 3 paquetes con: valor anual, valor mensual (÷12), qué informe incluye, y el desglose interno (días, costo, margen $ y %) visible SOLO para roles internos, nunca para el cliente. La propuesta al cliente muestra valor mensual (protagonista) + anual (debajo), sin desglose de costos ni $/m².

### Extensibilidad futura (dejar preparado, no construir)
- Estructura lista para agregar nuevos servicios (ej. robot de superficie, fumigación) como nuevos "tipos de servicio" sin refactorizar el motor.
- Estructura lista para segundo equipo/flota (multiplicar capacidad) y para tarifas por ciudad/territorio (cuando haya subfranquicias).
- Los rangos de techo son datos editables, no lógica: si Noruega cambia sus tarifas o rangos, se edita la tabla `roof_inspection_tiers`, no el código.
